package com.cg.banking.controllers;
import java.util.ArrayList;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.services.BankingService;

@Controller
public class BankingController {
	@Autowired
	private BankingService bankingService;
	Customer customer;
	Account account;
	Transaction transaction;
	@RequestMapping("/registerCustomer")
	public ModelAndView registerCustomerAction(@Valid@ModelAttribute Customer customer,BindingResult bindingResultCustomer,@Valid@ModelAttribute Account account ,BindingResult bindingResultAccount) {
		if(bindingResultCustomer.hasErrors())
			return new ModelAndView("registerPage");
		if(bindingResultAccount.hasErrors())
			return new ModelAndView("registerPage");
		customer=bankingService.openAccount(customer,account);
		return new ModelAndView("registrationSuccessPage", "customer", customer);
	}
	/*@RequestMapping("/CalculateNetSalary")
	public ModelAndView calculateNetSalary(@RequestParam("associateId")int associateId){
		int netSalary=payrollServices.calculateNetSalary(associateId);
		return new ModelAndView("displayNetSalary", "netSalary", netSalary);
	}
	@RequestMapping("/AssociateDetails")
	public ModelAndView getAssociateDeatils(@RequestParam("associateId")int associateId){
		associate=payrollServices.getAssociateDetails(associateId);
		return new ModelAndView("displayAssociateDetailsPage", "associate", associate);
	}
	@RequestMapping("/AllAssociateDetails")
	public ModelAndView getAllAssociateDeatils(){
		ArrayList<Associate> associates=payrollServices.getAllAsociateDetails();
		return new ModelAndView("displayAllAssociateDetailsPage", "associates", associates);
	}*/
}